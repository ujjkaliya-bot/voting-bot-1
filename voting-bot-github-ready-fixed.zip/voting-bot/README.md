# Telegram Voting & Giveaway Bot

A source-code repository for a Telegram channel voting/giveaway bot using **Python, aiogram 2.x and MongoDB**. This repository is provided as code; it is not deployed or running automatically.

## Included workflow

- `/start` menu with CONNECT, CREATE, MANAGE and HOW TO USE.
- CONNECT verifies the bot is an administrator in a channel and saves that channel for the owner.
- CREATE creates a giveaway and generates a Telegram deep-link for registration.
- Participants open the link, submit a display name and upload a Telegram photo as their DP.
- The bot posts the participant photo/profile with a Vote button to the connected channel.
- One vote per Telegram account per giveaway is enforced with a MongoDB unique index; self-voting is blocked.
- MANAGE lists the owner's giveaways; the owner can close one and see the current top participant.

## Requirements

- Python 3.9–3.11 recommended for this aiogram 2.x project.
- A Telegram bot token from BotFather.
- A MongoDB database (for example MongoDB Atlas).
- The bot must be an administrator in the channel where participant profiles are posted.

## Configuration

1. Copy `.env.example` to `.env`.
2. Set `BOT_TOKEN`, `MONGO_URI`, and `DB_NAME` in `.env`.
3. Install packages with `pip install -r requirements.txt`.
4. Start locally with `python main.py` when you are ready to run it.

Never commit `.env` or publish your bot token or database credentials. The `.gitignore` excludes `.env`.

## GitHub upload

Create a repository on GitHub, extract this ZIP, and upload the contents of the `voting-bot` folder (including `main.py`, `config/`, `database/`, `utils/`, and `requirements.txt`). No deployment is performed by uploading the source to GitHub.

## Quick test checklist

1. Start the bot and confirm `/start` displays the menu.
2. Connect a channel where both you and the bot are administrators.
3. Create a giveaway and open the JOIN HERE link using a second Telegram account.
4. Register a display name and upload a photo; confirm the profile appears in the channel.
5. Vote once, then try voting again from the same account; the second vote must be rejected.
6. Close the giveaway and confirm the winner is sent to the owner and announced in the channel.

## Important notes

- This code uses aiogram 2.x. Do not mix it with aiogram 3.x without updating the handlers.
- Voting is a simple community voting mechanism, not proof of a real-world identity or a guarantee against multiple accounts.
- The owner should check that the bot has permission to post photos in the connected channel.
