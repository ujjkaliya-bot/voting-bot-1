"""Telegram voting/giveaway bot (aiogram 2.x + MongoDB)."""
import asyncio
import logging
import os
import secrets
from datetime import datetime, timezone

from aiogram import Bot, Dispatcher, executor, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.utils.deep_linking import get_start_link
from dotenv import load_dotenv
from pymongo.errors import DuplicateKeyError

from config.database import db
from utils.keyboards import get_main_menu, get_contest_keyboard, get_manage_keyboard

load_dotenv()
logging.basicConfig(level=logging.INFO)
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is missing. Copy .env.example to .env and add your Telegram bot token.")

bot = Bot(token=BOT_TOKEN, parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot, storage=MemoryStorage())

class ConnectFlow(StatesGroup):
    channel = State()

class CreateFlow(StatesGroup):
    title = State()

class JoinFlow(StatesGroup):
    name = State()
    photo = State()


def uid() -> str:
    return secrets.token_hex(5)

async def ensure_indexes():
    # MongoDB enforces one vote per user per contest, including concurrent callbacks.
    await db.votes.create_index([("contest_id", 1), ("user_id", 1)], unique=True)
    await db.participants.create_index([("contest_id", 1), ("user_id", 1)], unique=True)
    await db.contests.create_index("contest_id", unique=True)

async def get_contest(contest_id):
    return await db.contests.find_one({"contest_id": contest_id})

async def refresh_vote_post(contest_id: str):
    contest = await get_contest(contest_id)
    if not contest:
        return
    participants = await db.participants.find({"contest_id": contest_id}).sort("votes", -1).to_list(length=100)
    for p in participants:
        if not p.get("post_chat_id") or not p.get("post_message_id"):
            continue
        text = (f"🏆 <b>{contest['title']}</b>\n\n"
                f"👤 <b>{p['name']}</b>\n🗳 Votes: <b>{p.get('votes', 0)}</b>\n\n"
                "Tap below to vote for this participant.")
        try:
            await bot.edit_message_caption(chat_id=p["post_chat_id"], message_id=p["post_message_id"],
                                           caption=text, reply_markup=get_contest_keyboard(contest_id, p["participant_id"]))
        except Exception:
            # Caption edits may fail if the channel post was manually changed/deleted.
            logging.exception("Could not refresh participant post")

@dp.message_handler(commands=["start"], state="*")
async def cmd_start(message: types.Message, state: FSMContext):
    await state.finish()
    args = message.get_args().strip()
    if args.startswith("join_"):
        contest_id = args[5:]
        contest = await get_contest(contest_id)
        if not contest or contest.get("status") != "active":
            await message.answer("This giveaway is unavailable or has ended.")
            return
        await state.update_data(contest_id=contest_id)
        await JoinFlow.name.set()
        await message.answer(f"🎉 <b>{contest['title']}</b>\n\nSend the name you want shown on your participant profile.")
        return
    await message.answer(
        "👋 <b>WELCOME TO VOTING & GIVEAWAY BOT</b>\n\n"
        "📁 CONNECT — connect a channel you administer\n"
        "➕ CREATE — create a giveaway\n"
        "⚡ MANAGE — view or close your giveaways\n"
        "🔎 HOW TO USE — instructions",
        reply_markup=get_main_menu())

@dp.callback_query_handler(lambda c: c.data == "btn_connect", state="*")
async def connect_start(call: types.CallbackQuery):
    await call.answer()
    await ConnectFlow.channel.set()
    await bot.send_message(call.from_user.id,
        "Send the channel username (for example <code>@mychannel</code>) or its numeric chat ID. "
        "Make sure this bot is an administrator in that channel.")

@dp.message_handler(state=ConnectFlow.channel, content_types=types.ContentTypes.TEXT)
async def connect_channel(message: types.Message, state: FSMContext):
    channel = message.text.strip()
    try:
        chat = await bot.get_chat(channel)
        me = await bot.get_me()
        member = await bot.get_chat_member(chat.id, me.id)
        if member.status not in ("administrator", "creator"):
            await message.answer("I need to be an administrator in that channel before connecting it.")
            return

        # Ensure the person connecting this channel is also an administrator.
        owner_member = await bot.get_chat_member(chat.id, message.from_user.id)
        if owner_member.status not in ("administrator", "creator"):
            await message.answer("You must be a channel administrator to connect this channel.")
            return

        await db.users.update_one({"user_id": message.from_user.id},
            {"$set": {"user_id": message.from_user.id, "channel_id": chat.id,
                      "channel_title": chat.title or chat.username, "updated_at": datetime.now(timezone.utc)}}, upsert=True)
        await state.finish()
        await message.answer(f"✅ Connected to <b>{chat.title or chat.username}</b>.", reply_markup=get_main_menu())
    except Exception as exc:
        logging.info("Channel connection failed: %s", exc)
        await message.answer("Couldn't connect this channel. Check the username/ID and confirm the bot is an administrator.")

@dp.callback_query_handler(lambda c: c.data == "btn_create", state="*")
async def create_start(call: types.CallbackQuery):
    await call.answer()
    user = await db.users.find_one({"user_id": call.from_user.id})
    if not user or not user.get("channel_id"):
        await bot.send_message(call.from_user.id, "First use CONNECT and connect a channel where this bot is an administrator.")
        return
    await CreateFlow.title.set()
    await bot.send_message(call.from_user.id, "Send a title for your giveaway (for example: October Community Voting).")

@dp.message_handler(state=CreateFlow.title, content_types=types.ContentTypes.TEXT)
async def create_title(message: types.Message, state: FSMContext):
    title = message.text.strip()[:100]
    if len(title) < 3:
        await message.answer("Please send a title with at least 3 characters.")
        return
    owner = await db.users.find_one({"user_id": message.from_user.id})
    if not owner or not owner.get("channel_id"):
        await state.finish()
        await message.answer("No connected channel found. Use CONNECT first.")
        return
    contest_id = uid()
    contest = {"contest_id": contest_id, "owner_id": message.from_user.id, "channel_id": owner["channel_id"],
               "channel_title": owner.get("channel_title", "Channel"), "title": title,
               "status": "active", "created_at": datetime.now(timezone.utc)}
    await db.contests.insert_one(contest)
    link = await get_start_link(f"join_{contest_id}", encode=False)
    await state.finish()
    await message.answer(
        f"✅ <b>Giveaway created!</b>\n\n<b>{title}</b>\n\n"
        f"Share this registration link with participants:\n{link}\n\n"
        "Participants open the link, enter a display name and upload a photo. Their profile will be posted to your connected channel.",
        reply_markup=get_manage_keyboard(contest_id, link))

@dp.message_handler(state=JoinFlow.name, content_types=types.ContentTypes.TEXT)
async def join_name(message: types.Message, state: FSMContext):
    name = message.text.strip()[:60]
    if len(name) < 2:
        await message.answer("Please send a name with at least 2 characters.")
        return
    await state.update_data(name=name)
    await JoinFlow.photo.set()
    await message.answer("Now upload your DP as a photo (not as a file/document).")

@dp.message_handler(state=JoinFlow.photo, content_types=types.ContentTypes.PHOTO)
async def join_photo(message: types.Message, state: FSMContext):
    data = await state.get_data()
    contest_id = data.get("contest_id")
    contest = await get_contest(contest_id)
    if not contest or contest.get("status") != "active":
        await state.finish()
        await message.answer("This giveaway is no longer active.")
        return
    participant_id = uid()
    photo_id = message.photo[-1].file_id
    participant = {"participant_id": participant_id, "contest_id": contest_id, "user_id": message.from_user.id,
                   "name": data["name"], "photo_file_id": photo_id, "votes": 0,
                   "created_at": datetime.now(timezone.utc)}
    try:
        await db.participants.insert_one(participant)
    except DuplicateKeyError:
        await state.finish()
        await message.answer("You have already registered for this giveaway.")
        return
    caption = (f"🏆 <b>{contest['title']}</b>\n\n👤 <b>{participant['name']}</b>\n🗳 Votes: <b>0</b>\n\n"
               "Tap below to vote for this participant.")
    try:
        post = await bot.send_photo(contest["channel_id"], photo_id, caption=caption,
                                    reply_markup=get_contest_keyboard(contest_id, participant_id))
        await db.participants.update_one({"participant_id": participant_id}, {"$set": {
            "post_chat_id": post.chat.id, "post_message_id": post.message_id}})
        await message.answer("✅ Your profile has been registered and posted to the giveaway channel!")
    except Exception:
        await db.participants.delete_one({"participant_id": participant_id})
        await message.answer("I couldn't post your profile. Please ask the giveaway admin to check the bot's channel permissions.")
        logging.exception("Failed to post participant")
    await state.finish()

@dp.message_handler(state=JoinFlow.photo, content_types=types.ContentTypes.ANY)
async def join_photo_invalid(message: types.Message):
    await message.answer("Please upload your DP as a Telegram photo, not text or a document.")

@dp.callback_query_handler(lambda c: c.data.startswith("vote:"))
async def vote_callback(call: types.CallbackQuery):
    try:
        _, contest_id, participant_id = call.data.split(":", 2)
        contest = await get_contest(contest_id)
        participant = await db.participants.find_one({"contest_id": contest_id, "participant_id": participant_id})
        if not contest or contest.get("status") != "active" or not participant:
            await call.answer("This giveaway is closed or the profile is unavailable.", show_alert=True)
            return
        if participant["user_id"] == call.from_user.id:
            await call.answer("You can't vote for your own profile.", show_alert=True)
            return
        await db.votes.insert_one({"contest_id": contest_id, "user_id": call.from_user.id,
                                   "participant_id": participant_id, "created_at": datetime.now(timezone.utc)})
        await db.participants.update_one({"contest_id": contest_id, "participant_id": participant_id}, {"$inc": {"votes": 1}})
        await call.answer("Your vote has been recorded!")
        await refresh_vote_post(contest_id)
    except DuplicateKeyError:
        await call.answer("You have already voted in this giveaway.", show_alert=True)
    except Exception:
        logging.exception("Vote failed")
        await call.answer("Couldn't record vote. Please try again.", show_alert=True)

@dp.callback_query_handler(lambda c: c.data == "btn_manage", state="*")
async def manage_list(call: types.CallbackQuery):
    await call.answer()
    cursor = db.contests.find({"owner_id": call.from_user.id}).sort("created_at", -1).limit(10)
    contests = await cursor.to_list(length=10)
    if not contests:
        await bot.send_message(call.from_user.id, "You haven't created any giveaways yet. Use CREATE to start one.")
        return
    for contest in contests:
        count = await db.participants.count_documents({"contest_id": contest["contest_id"]})
        await bot.send_message(call.from_user.id,
            f"🏆 <b>{contest['title']}</b>\nStatus: <b>{contest['status']}</b>\nParticipants: {count}",
            reply_markup=get_manage_keyboard(contest["contest_id"]))

@dp.callback_query_handler(lambda c: c.data.startswith("close:"))
async def close_contest(call: types.CallbackQuery):
    contest_id = call.data.split(":", 1)[1]
    result = await db.contests.update_one({"contest_id": contest_id, "owner_id": call.from_user.id, "status": "active"},
                                          {"$set": {"status": "closed", "closed_at": datetime.now(timezone.utc)}})
    if result.modified_count:
        await call.answer("Giveaway closed.")
        await call.message.edit_reply_markup()
        contest = await get_contest(contest_id)
        participants = await db.participants.find({"contest_id": contest_id}).sort("votes", -1).to_list(length=100)
        if participants:
            winner = participants[0]
            result_text = (
                f"🏁 <b>{contest['title']} — Results</b>\\n"
                f"🏆 Winner: <b>{winner['name']}</b>\\n"
                f"🗳 Votes: <b>{winner.get('votes', 0)}</b>"
            )
            await bot.send_message(call.from_user.id, result_text)
            try:
                await bot.send_message(contest["channel_id"], result_text)
            except Exception:
                logging.exception("Could not publish winner announcement to channel")
        else:
            await bot.send_message(call.from_user.id,
                f"🏁 <b>{contest['title']} — Results</b>\\nNo participants registered.")
    else:
        await call.answer("Giveaway not found, already closed, or you don't own it.", show_alert=True)

@dp.callback_query_handler(lambda c: c.data == "btn_help", state="*")
async def help_callback(call: types.CallbackQuery):
    await call.answer()
    await bot.send_message(call.from_user.id,
        "<b>How to use</b>\n1. Add this bot as an administrator to your channel.\n"
        "2. Press CONNECT and send the channel username/ID.\n3. Press CREATE and enter a giveaway title.\n"
        "4. Share the registration link. Participants enter a name and upload a photo.\n"
        "5. Their profiles appear in your channel; users can vote once per giveaway.\n"
        "6. Press MANAGE to see or close your giveaways.")

async def on_startup(_):
    await ensure_indexes()
    logging.info("Voting bot started")

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=False, on_startup=on_startup)
