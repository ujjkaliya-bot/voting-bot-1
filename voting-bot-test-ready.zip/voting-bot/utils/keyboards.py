from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def get_main_menu() -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(row_width=2)
    keyboard.add(InlineKeyboardButton(text="📁 CONNECT", callback_data="btn_connect"))
    keyboard.row(
        InlineKeyboardButton(text="➕ CREATE", callback_data="btn_create"),
        InlineKeyboardButton(text="⚡ MANAGE", callback_data="btn_manage"),
    )
    keyboard.add(InlineKeyboardButton(text="🔎 HOW TO USE", callback_data="btn_help"))
    return keyboard


def get_contest_keyboard(contest_id: str, participant_id: str) -> InlineKeyboardMarkup:
    # Compact callback data stays below Telegram's 64-byte callback_data limit.
    return InlineKeyboardMarkup().add(
        InlineKeyboardButton("🗳 Vote", callback_data=f"vote:{contest_id}:{participant_id}")
    )


def get_manage_keyboard(contest_id: str, join_link: str = "") -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(row_width=1)
    if join_link:
        keyboard.add(InlineKeyboardButton("🔗 JOIN HERE / Registration Link", url=join_link))
    keyboard.add(InlineKeyboardButton("🏁 Close giveaway & show winner", callback_data=f"close:{contest_id}"))
    return keyboard
