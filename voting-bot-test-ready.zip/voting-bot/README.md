# Telegram Voting & Giveaway Bot

Python source for a Telegram channel voting/giveaway bot using aiogram 2.x and MongoDB. Uploading this repository to GitHub does **not** start the bot by itself.

## Easy local test on Windows

1. Install Python 3.9–3.11 and make sure the `py` command works.
2. Extract this ZIP.
3. Open the extracted `voting-bot` folder and double-click `setup_windows.bat`.
4. When prompted, paste your Telegram bot token and MongoDB database-user password (both inputs are hidden). The script URL-encodes special characters in the database password and builds the connection URI for your Atlas cluster. These are saved to a local `.env` file.
5. Do not upload `.env` to GitHub or share it. `.gitignore` already excludes it.

If you prefer manual setup, copy `.env.example` to `.env`, fill in `BOT_TOKEN`, `MONGO_URI`, and `DB_NAME`, then run `pip install -r requirements.txt` and `python main.py`.

## Telegram setup

- Create a bot with Telegram's official BotFather and copy its token.
- Create a MongoDB database/cluster and a database user; allow network access from the machine running the bot. Keep the database password private.
- Add the bot as an administrator to the channel where participant profiles should be posted, with permission to post photos/messages.
- The person connecting the channel must also be a channel administrator.

## Included workflow

- `/start` menu with CONNECT, CREATE, MANAGE and HOW TO USE.
- CONNECT checks that the bot and connecting user are channel administrators.
- CREATE creates a giveaway and generates a registration deep-link.
- Participants submit a display name and photo; their profile is posted in the channel.
- MongoDB unique indexes enforce one vote per user per giveaway; self-voting is blocked.
- MANAGE lists giveaways and lets the owner close one and announce the current top participant.

## Important

- This uses aiogram 2.x; do not upgrade to aiogram 3.x without code changes.
- Test the full flow with a private/test channel before using it publicly.
- Voting is not proof of real-world identity and cannot fully prevent people using multiple accounts.
- Never commit or send `.env`; if a bot token has been exposed, revoke it through BotFather and generate a new one.
