from datetime import datetime, timezone
from pymongo.errors import DuplicateKeyError
from config.database import db

async def cast_vote(user_id: int, contest_id: str, participant_id: str) -> dict:
    """Record at most one vote per user in a contest (requires ensure_indexes at startup)."""
    contest = await db.contests.find_one({"contest_id": contest_id, "status": "active"})
    participant = await db.participants.find_one({"contest_id": contest_id, "participant_id": participant_id})
    if not contest or not participant:
        return {"success": False, "msg": "This giveaway or participant is unavailable."}
    if participant.get("user_id") == user_id:
        return {"success": False, "msg": "You cannot vote for your own profile."}
    try:
        await db.votes.insert_one({"user_id": user_id, "contest_id": contest_id,
                                   "participant_id": participant_id, "timestamp": datetime.now(timezone.utc)})
    except DuplicateKeyError:
        return {"success": False, "msg": "You have already voted in this giveaway."}
    await db.participants.update_one({"contest_id": contest_id, "participant_id": participant_id}, {"$inc": {"votes": 1}})
    return {"success": True, "msg": "Your vote has been recorded!"}
