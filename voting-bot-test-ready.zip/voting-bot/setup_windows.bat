@echo off
cd /d "%~dp0"
echo Installing required Python packages...
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo Package installation failed. Check that Python and pip are installed.
  pause
  exit /b 1
)
py configure_and_run.py
pause
