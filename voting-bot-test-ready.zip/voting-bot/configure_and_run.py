"""Secure local setup for the Telegram giveaway bot."""
import getpass
import json
import os
import subprocess
import sys
from pathlib import Path
from urllib.parse import quote_plus

root = Path(__file__).resolve().parent
print("Telegram Giveaway/Voting Bot setup")
print("Credentials are saved only to this computer in the local .env file.")
print("Do NOT upload .env to GitHub or share it.\n")

token = getpass.getpass("Telegram bot token (input hidden): ").strip()
password = getpass.getpass("MongoDB password for adib22980_db_user (input hidden): ")
dbname = input("Database name [lootverse_voting_bot]: ").strip() or "lootverse_voting_bot"
if not token or not password:
    print("ERROR: both Telegram token and MongoDB password are required.")
    sys.exit(1)
if any("\n" in v or "\r" in v for v in (token, password, dbname)):
    print("ERROR: values must each be a single line.")
    sys.exit(1)
encoded_password = quote_plus(password, safe="")
uri = ("mongodb+srv://adib22980_db_user:" + encoded_password +
       "@cluster0.cd2f0hu.mongodb.net/?retryWrites=true&w=majority")
(root / ".env").write_text(
    "BOT_TOKEN=" + json.dumps(token) + "\n" +
    "MONGO_URI=" + json.dumps(uri) + "\n" +
    "DB_NAME=" + json.dumps(dbname) + "\n",
    encoding="utf-8",
)
print("\nSaved .env locally. Starting the bot now; press Ctrl+C to stop.\n")
os.chdir(root)
subprocess.run([sys.executable, "main.py"], check=False)
