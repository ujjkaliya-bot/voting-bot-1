import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

load_dotenv()
MONGO_URI = os.getenv("MONGO_URI", "").strip()
DB_NAME = os.getenv("DB_NAME", "lootverse_voting_bot").strip()
if not MONGO_URI:
    # Allow importing source for repository inspection; actual startup will fail clearly.
    MONGO_URI = "mongodb://localhost:27017"

client = AsyncIOMotorClient(MONGO_URI, serverSelectionTimeoutMS=5000)
db = client[DB_NAME]
